package d7002d.Laboration4;

import d7002d.Laboration4.RunTest.FullPingTest;
import d7002d.Laboration4.RunTest.HostRouterTest;
import d7002d.Laboration4.RunTest.MobileTest;
import d7002d.Laboration4.RunTest.PingTest;

public class Run {
	public static void main(String[] args) {
		 MobileTest.mobileTest();
		  //FullPingTest.fullPingTest();
		//PingTest.pingTest();
		//HostRouterTest.hostRouterTest();
	}
}
